<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="alert alert-<?php echo e((Session::has('class') ? session('class') : 'info' )); ?>">
                <p><?php echo (Session::has('info') ? 'Terima kasih telah mengisi form. '.session('info') : 'Silahkan menuju halaman utama untuk mengisi form.'); ?></p>
            </div>
            <center> <a href="<?php echo e(secure_url('/')); ?>"> Kembali ke Halaman Utama</a> | <a href="<?php echo e(secure_url('/biodata/list.html')); ?>">Lihat Daftar Biodata</a> </center>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('biodata.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>