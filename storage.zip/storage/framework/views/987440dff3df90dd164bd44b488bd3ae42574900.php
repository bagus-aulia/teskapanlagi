<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="alert alert-danger <?php echo e((count($errors) > 0 ? '': 'hidden')); ?>">
              Ada kesalahan dalam peng-inputan data! Silahkan cek kembali inputan Anda. <br>
            </div>

            <div class="alert alert-warning <?php echo e((isset($notFound) ? '': 'hidden')); ?>">
               <?php echo (isset($notFound) ? $notFound : ''); ?>

            </div>

            <div class="alert alert-danger hidden" id="errorCharacter">
                <p>Penggunaan karakter tersebut tidak diperbolehkan!</p>
            </div>

            <div class="card">
                <div class="card-header"><?php echo (isset($judulForm) ? $judulForm : 'Isi Biodata Anda.'); ?></div>

                <div class="card-body">
                    <?php echo Form::open(['action' => 'BiodataController@store', 'method' => 'post', 'class' => 'form-horizontal']); ?>

                    <div class="form-group">
                      <?php echo Form::label('nama', 'Nama', ['class' => 'col-sm-3 control-label']); ?>

                      <div class="col-sm-9">
                        <?php echo Form::text('nama', (isset($nama) ? $nama : ""), ['class' => 'form-control', 'placeholder' => 'Nama', 'autofocus' => 'true', 'required' => 'true', 'id' => 'nama', 'onkeypress' => 'return keyValidate(event)']); ?>

                      </div>
                      <?php echo ($errors->has('nama')) ? Form::label('nama', $errors->first('nama') , ['class' => 'col-sm-12 control-label error']) : ''; ?>

                    </div>

                    <div class="form-group">
                      <?php echo Form::label('mail', 'Email', ['class' => 'col-sm-3 control-label']); ?>

                      <div class="col-sm-9">
                        <?php echo Form::email('mail', (isset($mail) ? $mail : ""), ['class' => 'form-control', 'placeholder' => 'Email', 'required' => 'true', 'onkeypress' => 'return keyValidate(event)']); ?>

                      </div>
                      <?php echo ($errors->has('mail')) ? Form::label('mail', $errors->first('mail') , ['class' => 'col-sm-12 control-label error']) : ''; ?>

                    </div>

                    <div class="form-group">
                      <?php echo Form::label('tglLahir', 'Tanggal Lahir (bulan/tanggal/tahun)', ['class' => 'col-sm-3 control-label']); ?>

                      <div class="col-sm-9">
                        <?php echo Form::date('tglLahir', (isset($tglLahir) ? $tglLahir : ""), ['class' => 'form-control', 'placeholder' => 'Tanggal Lahir', 'required' => 'true']); ?>

                      </div>
                      <?php echo ($errors->has('tglLahir')) ? Form::label('tglLahir', $errors->first('tglLahir') , ['class' => 'col-sm-12 control-label error']) : ''; ?>

                    </div>

                    <div class="form-group">
                      <?php echo Form::label('alamat', 'Alamat', ['class' => 'col-sm-3 control-label']); ?>

                      <div class="col-sm-9">
                        <?php echo Form::text('alamat', (isset($alamat) ? $alamat : ""), ['class' => 'form-control', 'placeholder' => 'Alamat', 'required' => 'true', 'onkeypress' => 'return keyValidate(event)']); ?>

                        <?php echo Form::hidden('namaFile', (isset($namaFile) ? $namaFile : ""), ['class' => 'form-control', 'placeholder' => 'Nama File', 'id' => 'namaFile', 'onkeypress' => 'return keyValidate(event)']); ?>

                      </div>
                      <?php echo ($errors->has('alamat')) ? Form::label('alamat', $errors->first('alamat') , ['class' => 'col-sm-12 control-label error']) : ''; ?>

                    </div>

                    <div class="form-group">
                      <div class="col-sm-9 col-sm-offset-3">
                        <?php echo Form::submit('Simpan', ['class' => "btn btn-primary", 'id' => 'btnSimpan']); ?>

                        <button type="button" class="btn btn-danger" onclick="resetInput()">Reset</button>
                      </div>
                    </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('biodata.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>