<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
          <?php if(Session::has('info') or count($errors) > 0): ?>
          <div class="alert alert-success">
              <h4>Informasi</h4>
              <?php echo session('info'); ?>

          </div>
          <?php endif; ?>
            <div class="card">
                <div class="card-header">Daftar Biodata.</div>

                <div class="card-body">
                    <table id="daftarFile" class="display">
                      <thead>
                          <tr>
                              <th>No</th>
                              <th>Nama File</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php $__currentLoopData = $allFile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($no); ?></td>
                              <td><?php echo e($file); ?></td>
                              <td>
                                  <a href="<?php echo e(url('biodata/'.$file)); ?>" class="btn btn-primary btn-sm"> Edit</a>
                              </td>
                          </tr>
                          <?php $no++; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>