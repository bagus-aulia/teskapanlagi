<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="alert alert-danger <?php echo e((isset($error) ? '': 'hidden')); ?>">
                <p><?php echo (isset($error) ? $error: ''); ?></p>
            </div>

            <div class="alert alert-danger hidden" id="errorCharacter">
                <p>Penggunaan karakter tersebut tidak diperbolehkan!</p>
            </div>

            <div class="card">
                <div class="card-header"><?php echo (isset($judulForm) ? $judulForm : 'Isi Biodata Anda.'); ?></div>

                <div class="card-body">
                    <?php echo Form::open(['url' => 'biodata/store.html', 'method' => 'post', 'class' => 'form-horizontal']); ?>

                    <div class="form-group">
                      <?php echo Form::label('nama', 'Nama', ['class' => 'col-sm-3 control-label']); ?>

                      <div class="col-sm-9">
                        <?php echo Form::text('nama', (isset($nama) ? $nama : ""), ['class' => 'form-control', 'placeholder' => 'Nama', 'autofocus' => 'true', 'required' => 'true', 'id' => 'nama', 'onkeypress' => 'return keyValidate(event)']); ?>

                      </div>
                    </div>

                    <div class="form-group">
                      <?php echo Form::label('sekolah', 'Sekolah', ['class' => 'col-sm-3 control-label']); ?>

                      <div class="col-sm-9">
                        <?php echo Form::text('sekolah', (isset($sekolah) ? $sekolah : ""), ['class' => 'form-control', 'placeholder' => 'Sekolah', 'required' => 'true']); ?>

                      </div>
                    </div>

                    <div class="form-group">
                      <?php echo Form::label('tglLahir', 'Tanggal Lahir', ['class' => 'col-sm-3 control-label']); ?>

                      <div class="col-sm-9">
                        <?php echo Form::date('tglLahir', (isset($tglLahir) ? $tglLahir : ""), ['class' => 'form-control', 'placeholder' => 'Tanggal Lahir', 'required' => 'true']); ?>

                      </div>
                    </div>

                    <div class="form-group">
                      <?php echo Form::label('alamat', 'Alamat', ['class' => 'col-sm-3 control-label']); ?>

                      <div class="col-sm-9">
                        <?php echo Form::text('alamat', (isset($alamat) ? $alamat : ""), ['class' => 'form-control', 'placeholder' => 'Alamat', 'required' => 'true']); ?>

                      </div>
                    </div>

                    <div class="form-group">
                      <?php echo Form::label('posisi', 'Posisi', ['class' => 'col-sm-3 control-label']); ?>

                      <div class="col-sm-9">
                        <?php echo Form::text('posisi', (isset($posisi) ? $posisi : ""), ['class' => 'form-control', 'placeholder' => 'Posisi', 'required' => 'true']); ?>

                        <?php echo Form::hidden('namaFile', (isset($namaFile) ? $namaFile : ""), ['class' => 'form-control', 'placeholder' => 'Nama File', 'id' => 'namaFile']); ?>

                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-sm-9 col-sm-offset-3">
                        <?php echo Form::submit('Simpan', ['class' => "btn btn-primary", 'id' => 'btnSimpan']); ?>

                        <button type="button" class="btn btn-danger" onclick="resetInput()">Reset</button>
                      </div>
                    </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>